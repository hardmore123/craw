"use strict";

let FILE_ID = null;
let SHEETS = [];
let TASK_ID = null;
let OFFSET = 0;
let ROWS = [];
let POLL = null;

const $ = (id) => document.getElementById(id);

// 字段中文标签与列映射默认
const FIELDS = [
  ["cert_no", "证书号", "I"],
  ["result", "结果列", "M"],
  ["manufacturer", "制造商", ""],
  ["factory", "生产厂", ""],
  ["model", "型号", ""],
  ["standard", "标准", ""],
  ["cert_status", "证书状态", ""],
  ["agency", "机构列", ""],
];

// ---------------- 上传 ----------------
$("btn-upload").onclick = async () => {
  const f = $("file").files[0];
  if (!f) { setMsg("upload-msg", "请先选择 .xlsx 文件", true); return; }
  const fd = new FormData();
  fd.append("file", f);
  setMsg("upload-msg", "上传解析中…", false);
  try {
    const r = await fetch("/api/upload", { method: "POST", body: fd });
    const d = await r.json();
    if (d.error) { setMsg("upload-msg", d.error, true); return; }
    FILE_ID = d.file_id;
    SHEETS = d.sheets;
    setMsg("upload-msg", `已解析：${d.filename}，共 ${d.sheets.length} 个工作表`, false, true);
    renderSheets();
    $("step-map").classList.remove("hidden");
    refreshUlStatus();
  } catch (e) { setMsg("upload-msg", "上传失败：" + e, true); }
};

// ---------------- 列映射渲染 ----------------
function renderSheets() {
  const box = $("sheets");
  box.innerHTML = "";
  const targetHint = ["认证类别CB", "认证类别UL", "CB", "UL"];
  SHEETS.forEach((s, i) => {
    const enabled = targetHint.some(t => s.name.includes(t)) || SHEETS.length <= 2;
    const div = document.createElement("div");
    div.className = "sheet-map";
    const cols = FIELDS.map(([k, label, def]) =>
      `<label>${label}<input data-sheet="${i}" data-key="${k}" value="${def}" /></label>`
    ).join("");
    const previewText = s.preview.map(row =>
      "r" + row.row + "  " + row.cells.map(c => `${c.col}=${c.value}`).join("  ")
    ).join("\n");
    div.innerHTML = `
      <div class="title"><label><input type="checkbox" data-sheet="${i}" class="sheet-en" ${enabled ? "checked" : ""} />
        ${s.name}（${s.max_row} 行 × ${s.max_col} 列）</label></div>
      <label>数据起始行 <input data-sheet="${i}" data-key="first_data_row" value="2" style="width:60px" /></label>
      <div class="cols">${cols}</div>
      <div class="preview">${previewText || "（无预览）"}</div>`;
    box.appendChild(div);
  });
  // 套用到全部：改第一个 sheet 的列时同步（简单起见提供一个按钮）
}

// ---------------- 开始核对 ----------------
$("btn-run").onclick = async () => {
  const sheets = SHEETS.map((s, i) => {
    const en = document.querySelector(`.sheet-en[data-sheet="${i}"]`).checked;
    const colmap = {};
    document.querySelectorAll(`input[data-sheet="${i}"][data-key]`).forEach(inp => {
      colmap[inp.dataset.key] = inp.value.trim();
    });
    return { name: s.name, enabled: en, colmap };
  });
  const body = {
    file_id: FILE_ID,
    sheets,
    limit: parseInt($("limit").value || "0"),
    proxy: $("proxy").value.trim(),
    default_agency: $("default_agency").value,
    detail_col: $("detail_col").value.trim(),
    stop_on_blocked: $("stop_on_blocked").checked,
  };
  const r = await fetch("/api/run", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const d = await r.json();
  if (d.error) { alert(d.error); return; }
  TASK_ID = d.task_id; OFFSET = 0; ROWS = [];
  $("step-progress").classList.remove("hidden");
  $("step-result").classList.remove("hidden");
  $("result-table").querySelector("tbody").innerHTML = "";
  startPoll();
};

// ---------------- 轮询进度 ----------------
function startPoll() {
  if (POLL) clearInterval(POLL);
  POLL = setInterval(pollOnce, 1000);
  pollOnce();
}
async function pollOnce() {
  if (!TASK_ID) return;
  const r = await fetch(`/api/progress?id=${TASK_ID}&offset=${OFFSET}`);
  const d = await r.json();
  if (d.error) return;
  OFFSET = d.next_offset;
  (d.new_rows || []).forEach(row => { ROWS.push(row); appendRow(row); });
  const pct = d.total ? Math.round(d.done / d.total * 100) : 0;
  $("bar").style.width = pct + "%";
  $("progress-text").textContent =
    `${statusText(d.status)} — 进度 ${d.done}/${d.total}` +
    (d.cur_cert ? `，当前：${d.cur_sheet} / ${d.cur_cert} / ${d.cur_agency}` : "");
  renderStats(d.stats);
  if (["completed", "stopped", "failed"].includes(d.status)) {
    clearInterval(POLL); POLL = null;
    $("btn-cancel").disabled = true;
    if (d.stop_reason === "blocked") $("progress-text").textContent += "（因网络拦截提前停止，已保存已完成部分）";
    if (d.stop_reason === "user_cancel") $("progress-text").textContent += "（已取消，已保存已完成部分）";
    if (d.status === "failed") $("progress-text").textContent += "，错误：" + d.error;
    if (d.degraded) setMsg("degraded-msg", d.degraded, true);
    applyFilter();
  }
}

function statusText(s) {
  return { pending: "准备中", running: "运行中", completed: "已完成",
           stopped: "已停止", failed: "失败" }[s] || s;
}

function renderStats(st) {
  if (!st) return;
  $("stats").innerHTML = [
    ["查到", st.found], ["官网未查到", st.not_found], ["被拦截", st.blocked],
    ["字段全一致", st.consistent], ["需人工复核", st.review],
  ].map(([k, v]) => `<span class="chip">${k}：${v}</span>`).join("");
}

// ---------------- 结果表 ----------------
function rowClass(row) {
  if (["not_found", "error", "unsupported"].includes(row.status)) return "row-problem";
  if (row.status === "blocked") return "row-blocked";
  if (!row.consistent) return "row-mismatch";
  return "row-ok";
}
function appendRow(row) {
  const tb = $("result-table").querySelector("tbody");
  const tr = document.createElement("tr");
  tr.className = rowClass(row);
  tr.dataset.idx = ROWS.length - 1;
  tr.innerHTML = `<td>${row.sheet}</td><td>${row.row}</td><td>${row.cert_no}</td>
    <td>${row.agency}</td><td class="verdict">${escapeHtml(row.verdict_text)}</td>
    <td>${statusZh(row.status)}</td>`;
  tr.onclick = () => showDetail(parseInt(tr.dataset.idx));
  tb.appendChild(tr);
}
function statusZh(s) {
  return { found: "查到", not_found: "官网无", blocked: "被拦截",
           error: "失败", unsupported: "未支持" }[s] || s;
}

// ---------------- 筛选 ----------------
$("filter").onchange = applyFilter;
function applyFilter() {
  const mode = $("filter").value;
  document.querySelectorAll("#result-table tbody tr").forEach(tr => {
    const row = ROWS[parseInt(tr.dataset.idx)];
    let show = true;
    if (mode === "mismatch") show = row.status === "found" && !row.consistent;
    else if (mode === "problem") show = ["not_found", "blocked", "error", "unsupported"].includes(row.status);
    tr.style.display = show ? "" : "none";
  });
}

// ---------------- 行明细 ----------------
function showDetail(idx) {
  const row = ROWS[idx];
  $("modal-title").textContent = `${row.sheet} 第 ${row.row} 行 · ${row.cert_no}（${row.agency}）`;
  const tb = $("modal-table").querySelector("tbody");
  if (!row.fields || !row.fields.length) {
    tb.innerHTML = `<tr><td colspan="4">${escapeHtml(row.verdict_text)}</td></tr>`;
  } else {
    tb.innerHTML = row.fields.map(f => {
      const cls = f.verdict === "不一致" ? "fv-mismatch"
        : f.verdict === "一致" ? "fv-match" : "fv-missing";
      const site = f.verdict === "网站无此项" ? "（官网未提供）" : escapeHtml(f.site_value);
      const v = f.verdict + (f.detail ? `（${escapeHtml(f.detail)}）` : "");
      return `<tr><td>${f.label}</td><td>${escapeHtml(f.sheet_value)}</td>
        <td>${site}</td><td class="${cls}">${v}</td></tr>`;
    }).join("");
  }
  $("modal-url").innerHTML = row.source_url
    ? `来源：<a href="${row.source_url}" target="_blank">${row.source_url}</a>` : "";
  $("detail-modal").classList.remove("hidden");
}
$("modal-close").onclick = () => $("detail-modal").classList.add("hidden");
$("detail-modal").onclick = (e) => { if (e.target.id === "detail-modal") $("detail-modal").classList.add("hidden"); };

// ---------------- 取消 / 下载 ----------------
$("btn-cancel").onclick = async () => {
  if (!TASK_ID) return;
  await fetch("/api/cancel", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ task_id: TASK_ID }),
  });
};
$("btn-download").onclick = () => {
  if (TASK_ID) window.location = `/api/download?id=${TASK_ID}`;
};

// ---------------- UL 登录 ----------------
async function refreshUlStatus() {
  try {
    const d = await (await fetch("/api/ul-status")).json();
    const el = $("ul-state");
    if (d.login_running) { el.textContent = "登录中…（在弹出的 Edge 里完成）"; el.className = ""; }
    else if (d.logged_in) { el.textContent = "已登录"; el.className = "on"; }
    else { el.textContent = "未登录"; el.className = "off"; }
  } catch (e) {}
}
$("btn-ul-login").onclick = async () => {
  await fetch("/api/ul-login", { method: "POST" });
  setTimeout(refreshUlStatus, 800);
  const iv = setInterval(refreshUlStatus, 3000);
  setTimeout(() => clearInterval(iv), 8 * 60 * 1000);
};

// ---------------- 工具 ----------------
function setMsg(id, text, isErr, isOk) {
  const el = $(id);
  el.textContent = text;
  el.className = "msg" + (isErr ? " err" : isOk ? " ok" : "");
}
function escapeHtml(s) {
  return (s == null ? "" : String(s)).replace(/[&<>"]/g,
    c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
}
