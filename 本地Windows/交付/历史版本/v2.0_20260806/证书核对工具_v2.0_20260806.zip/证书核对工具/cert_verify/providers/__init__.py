"""Provider 注册与路由。"""
from __future__ import annotations

from ..http_client import HttpClient
from ..models import UNSUPPORTED, CertRecord
from .base import BaseProvider
from .tuv_rheinland import TuvRheinlandProvider
from .ul import UlProvider
from .vde import VdeProvider

__all__ = [
    "BaseProvider", "TuvRheinlandProvider", "UlProvider", "VdeProvider",
    "ProviderRouter",
]


class ProviderRouter:
    """按 表格里的"认证机构"列 或 证书号形态 选 Provider。"""

    def __init__(self, client: HttpClient | None = None, headless: bool = True,
                 proxy: str | None = None):
        client = client or HttpClient(proxy=proxy)
        ul = UlProvider(headless=headless, proxy=proxy)
        ul._reuse = True          # 批量核对时复用同一个浏览器会话，别每行重启 Edge
        self.providers: dict[str, BaseProvider] = {
            "TUV-Rheinland": TuvRheinlandProvider(client),
            "VDE": VdeProvider(headless=headless, proxy=proxy, client=client),
            "UL": ul,
        }
        # 机构名的各种写法 -> provider key
        self.aliases = {
            "tuv": "TUV-Rheinland", "tüv": "TUV-Rheinland", "tuv rheinland": "TUV-Rheinland",
            "tuv-r": "TUV-Rheinland", "莱茵": "TUV-Rheinland", "tuvr": "TUV-Rheinland",
            "vde": "VDE",
            "ul": "UL", "ul-cb": "UL", "cb": "UL",
        }

    def resolve(self, cert_no: str, agency_hint: str = "") -> BaseProvider | None:
        hint = (agency_hint or "").strip().lower()
        if hint:
            for alias, key in self.aliases.items():
                if alias in hint:
                    return self.providers[key]
        for p in self.providers.values():          # 退化到按证书号形态猜
            if p.matches(cert_no):
                return p
        return None

    def query(self, cert_no: str, agency_hint: str = "") -> CertRecord:
        p = self.resolve(cert_no, agency_hint)
        if p is None:
            return CertRecord(query_no=cert_no, source="?", status=UNSUPPORTED,
                              message=f"无法判断认证机构（证书号={cert_no!r}, 提示={agency_hint!r}）")
        return p.query(cert_no)

    def close(self) -> None:
        """释放各 Provider 持有的资源（如 UL 的浏览器会话）。批量结束时调用。"""
        for p in self.providers.values():
            close = getattr(p, "close", None)
            if callable(close):
                try:
                    close()
                except Exception:
                    pass
